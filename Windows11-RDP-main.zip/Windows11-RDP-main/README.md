# Windows 11 RDP

Free Windows 11 RDP (4 HOURS)

<img src="https://telegra.ph/file/ae06b28d76b6fb3c1dc69.jpg" width="500" />

## METHOD:

- `Go to:` [Katacoda Terminal](https://www.katacoda.com/thuonghaivn2711/scenarios/course3)
- `Login to the website using email.`
- `Wait till terminal process to finish.`
- `Finally you will get RDP login details.`
- `Do not close Katacoda Terminal.`
- `Maximum time limit is 4 hours.`
- `You can create many RDPs using this method.`

## DISCLAIMER:

 - `Do not overuse this method.`
 - `No illegal things.`
